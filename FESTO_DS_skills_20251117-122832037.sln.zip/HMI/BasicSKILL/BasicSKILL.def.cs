using System;
using NxtControl.GuiFramework;
using NxtControl.Services;


#region Definitions;
#region BasicSKILL_HMI;
#endregion BasicSKILL_HMI;

#endregion Definitions;

