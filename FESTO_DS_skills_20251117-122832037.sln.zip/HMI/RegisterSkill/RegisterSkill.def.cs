using System;
using NxtControl.GuiFramework;
using NxtControl.Services;


#region Definitions;
#region RegisterSkill_HMI;
#endregion RegisterSkill_HMI;

#endregion Definitions;

