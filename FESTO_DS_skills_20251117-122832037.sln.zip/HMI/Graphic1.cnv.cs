/*
 * Created by nxtSTUDIO.
 * User: Andrei
 * Date: 7/13/2016
 * Time: 3:24 PM
 * 
 */

using System;
using System.Drawing;
using NxtControl.GuiFramework;

namespace HMI.Main.Graphics
{
	/// <summary>
	/// Description of Graphic1.
	/// </summary>
	public partial class Graphic1 : NxtControl.GuiFramework.GraphicSymbol
	{
		public Graphic1()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
		}
	}
}
