using System;
using NxtControl.GuiFramework;
using NxtControl.Services;


#region Definitions;
#region Model_HMI;
#endregion Model_HMI;

#endregion Definitions;

