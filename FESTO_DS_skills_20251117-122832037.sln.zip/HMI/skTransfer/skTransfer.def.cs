using System;
using NxtControl.GuiFramework;
using NxtControl.Services;


#region Definitions;
#region skTransfer_HMI;
#endregion skTransfer_HMI;

#endregion Definitions;

