using System;
using NxtControl.GuiFramework;
using NxtControl.Services;


#region Definitions;
#region Test_HMI;
#endregion Test_HMI;

#endregion Definitions;

