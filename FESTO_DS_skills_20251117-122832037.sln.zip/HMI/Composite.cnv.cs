﻿/*
 * Created by EcoStruxure Automation Expert.
 * User: vv263
 * Date: 11/14/2025
 * Time: 12:50 PM
 * 
 */

using System;
using NxtControl.GuiFramework;


namespace HMI.Main.Canvases
{
	/// <summary>
	/// Description of Composite.
	/// </summary>
	public partial class Composite : NxtControl.GuiFramework.HMICanvas
	{
		public Composite()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
		}
	}
}
