﻿/*
 * Created by EcoStruxure Automation Expert.
 * User: midxav
 * Date: 12/2/2024
 * Time: 9:45 AM
 * 
 */

using System;
using NxtControl.GuiFramework;


namespace HMI.Main.Canvases
{
	/// <summary>
	/// Description of Canvas2.
	/// </summary>
	public partial class Canvas2 : NxtControl.GuiFramework.HMICanvas
	{
		public Canvas2()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
		}
	}
}
