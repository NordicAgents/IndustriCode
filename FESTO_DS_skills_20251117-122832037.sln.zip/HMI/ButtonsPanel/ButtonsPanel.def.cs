using System;
using NxtControl.GuiFramework;
using NxtControl.Services;


#region Definitions;
#region ButtonsPanel_HMI;
#endregion ButtonsPanel_HMI;

#endregion Definitions;

