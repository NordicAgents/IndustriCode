using System;
using NxtControl.GuiFramework;
using NxtControl.Services;


#region Definitions;
#region SKILL_HMI;
#endregion SKILL_HMI;

#endregion Definitions;

